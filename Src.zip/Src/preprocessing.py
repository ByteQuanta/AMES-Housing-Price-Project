# ================================================================
# 🏠 Ames Housing - Missing Value Pipeline
# ================================================================

# ---------------------------------------------------------------
# 0️⃣ Deterministic (Reproducible) Environment Settings
# ---------------------------------------------------------------
import os
import random
import numpy as np

SEED = 42
os.environ['PYTHONHASHSEED'] = str(SEED)
np.random.seed(SEED)
random.seed(SEED)

# ---------------------------------------------------------------
# 1️⃣ Required Libraries
# ---------------------------------------------------------------
import pandas as pd
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.preprocessing import OrdinalEncoder

# ---------------------------------------------------------------
# 2️⃣ Load Dataset
# ---------------------------------------------------------------
df = pd.read_csv("your file's path/AmesHousing.csv")

# Clean column names
df.columns = df.columns.str.strip().str.replace(' ', '_').str.replace('-', '_')

# ---------------------------------------------------------------
# 3️⃣ Missing Value Summary
# ---------------------------------------------------------------
missing_summary = df.isnull().sum().sort_values(ascending=False)
missing_percent = (df.isnull().sum() / len(df) * 100).sort_values(ascending=False)
missing_df = pd.concat([missing_summary, missing_percent], axis=1, keys=['Missing Count', 'Missing %'])
print("Missing Value Summary:\n", missing_df[missing_df['Missing Count'] > 0])

# ---------------------------------------------------------------
# 4️⃣ Missing Value Indicators
# ---------------------------------------------------------------
missing_indicator_cols = [col for col in df.columns if df[col].isnull().sum() > 0]
for col in missing_indicator_cols:
    df[col + "_was_missing"] = df[col].isnull().astype(int)

# ---------------------------------------------------------------
# 5️⃣ Fill Structural Missing Values (Categorical)
# ---------------------------------------------------------------
structural_cols = [
    "Pool_QC", "Misc_Feature", "Alley", "Fence", "Fireplace_Qu",
    "Garage_Finish", "Garage_Qual", "Garage_Cond", "Garage_Type",
    "Bsmt_Qual", "Bsmt_Cond", "Bsmt_Exposure", "BsmtFin_Type_1", "BsmtFin_Type_2"
]
for col in structural_cols:
    if col in df.columns:
        df[col] = df[col].fillna("None")

# ---------------------------------------------------------------
# 6️⃣ Separate Numeric & Categorical Columns
# ---------------------------------------------------------------
numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
categorical_cols = df.select_dtypes(include='object').columns.tolist()

# ---------------------------------------------------------------
# 7️⃣ Fill Missing Numeric Values with MICE (Deterministic)
# ---------------------------------------------------------------
mice_cols = [col for col in numeric_cols if df[col].isnull().sum() > 0]
if mice_cols:
    mice_imputer = IterativeImputer(max_iter=10, random_state=SEED)
    df[mice_cols] = mice_imputer.fit_transform(df[mice_cols])

# ---------------------------------------------------------------
# 8️⃣ Fill Missing Categorical Values with Mode
# ---------------------------------------------------------------
for col in categorical_cols:
    if df[col].isnull().sum() > 0:
        df[col] = df[col].fillna(df[col].mode()[0])

# ---------------------------------------------------------------
# 9️⃣ Ordinal Encode Categorical Features
# ---------------------------------------------------------------
ord_enc = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
df[categorical_cols] = ord_enc.fit_transform(df[categorical_cols])

# ---------------------------------------------------------------
# 🔟 Save Cleaned CSV
# ---------------------------------------------------------------
clean_path = "your file's path/AmesHousing_Clean.csv"
df.to_csv(clean_path, index=False)
print(f"💾 Clean dataset saved to: {clean_path}")
print("✅ Missing value processing pipeline successfully completed.")


