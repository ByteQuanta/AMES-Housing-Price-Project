# ================================================================
# 🏠 Ames Housing Modeling + Assumption Checks
# ================================================================

import dash
from dash import dcc, html, Input, Output
import plotly.express as px
import statsmodels.api as sm  # kept for future tests (Jarque-Bera, Breusch-Pagan, etc.)

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson

# ---------------------------------------------------------------
# 1️⃣ Load Clean Data
# ---------------------------------------------------------------
clean_data = pd.read_csv(clean_path)

# ---------------------------------------------------------------
# 2️⃣ Remove Multicollinearity (VIF Cleaning)
# ---------------------------------------------------------------
def calculate_vif(df, target_col='SalePrice', vif_threshold=10.0):
    numeric_df = df.select_dtypes(include=[np.number]).drop(columns=[target_col], errors='ignore').dropna()
    features = numeric_df.columns
    dropped = True
    while dropped:
        dropped = False
        vif_data = pd.DataFrame()
        vif_data["Feature"] = features
        vif_data["VIF"] = [variance_inflation_factor(numeric_df[features].values, i)
                           for i in range(len(features))]
        max_vif = vif_data["VIF"].max()
        if max_vif > vif_threshold:
            max_feature = vif_data.sort_values("VIF", ascending=False)["Feature"].iloc[0]
            print(f"⚠️ '{max_feature}' has a very high VIF ({max_vif:.2f}) → removing")
            numeric_df = numeric_df.drop(columns=[max_feature])
            features = numeric_df.columns
            dropped = True
    return numeric_df, vif_data

X_vif_clean, vif_final = calculate_vif(clean_data)
print("\n✅ VIF cleaning completed.")
print(f"Remaining features: {len(X_vif_clean.columns)}")


# ---------------------------------------------------------------
# 3️⃣ Model + Prediction Data (RobustScaler + Linear Regression)
# ---------------------------------------------------------------
X = X_vif_clean
y = clean_data['SalePrice']

from sklearn.utils import check_random_state
rng = check_random_state(SEED)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=SEED
)

lr_model = make_pipeline(
    RobustScaler(),
    LinearRegression()
)

# Fit model
lr_model.fit(X_train, y_train)

# ---------------------------------------------------------------
# 4️⃣ Durbin–Watson (Residual Independence) - POST MODEL
# ---------------------------------------------------------------
y_train_pred = lr_model.predict(X_train)
residuals_train = y_train - y_train_pred

dw_stat = durbin_watson(residuals_train)
print(f"\n🧩 Durbin-Watson (train residuals): {dw_stat:.4f}")
if 1.5 < dw_stat < 2.5:
    print("✅ No autocorrelation detected (independence assumption satisfied).")
else:
    print("⚠️ Possible autocorrelation in residuals (weak independence).")

# ---------------------------------------------------------------
# 5️⃣ Test Set Predictions & Evaluation
# ---------------------------------------------------------------
y_test_pred = lr_model.predict(X_test)

X_test_copy = X_test.copy()
X_test_copy['SalePrice'] = y_test.values
X_test_copy['Predicted_Price'] = y_test_pred

rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
r2 = r2_score(y_test, y_test_pred)
print("\n📊 Model Results (Test Set):")
print(f"RMSE: {rmse:,.2f}")
print(f"R²: {r2:.4f}")




