# ================================================================
# 🏠 Ames Housing Dashboard
# ================================================================

# ---------------------------------------------------------------
# 6️⃣ Dash Application
# ---------------------------------------------------------------
app = dash.Dash(__name__, suppress_callback_exceptions=True)
app.title = "Ames Housing - EDA + Model Dashboard"

# ---------------------------------------------------------------
# 7️⃣ Common Filter Components
# ---------------------------------------------------------------
def filter_controls(id_prefix, data):
    return html.Div([
        html.Div([
            html.Label("Select Neighborhood:"),
            dcc.Dropdown(
                id=f'{id_prefix}-neighborhood-dropdown',
                options=[{'label': n, 'value': n} for n in sorted(data['Neighborhood'].unique())],
                value=[sorted(data['Neighborhood'].unique())[0]],
                multi=True
            ),
        ], style={'flex': '1', 'padding': '0 10px'}),

        html.Div([
            html.Label("Select Kitchen Quality:"),
            dcc.Dropdown(
                id=f'{id_prefix}-kitchenqual-dropdown',
                options=[{'label': q, 'value': q} for q in sorted(data['Kitchen_Qual'].dropna().unique())],
                value=[sorted(data['Kitchen_Qual'].dropna().unique())[0]],
                multi=True
            ),
        ], style={'flex': '1', 'padding': '0 10px'}),

        html.Div([
            html.Label("SalePrice Range:"),
            dcc.RangeSlider(
                id=f'{id_prefix}-price-slider',
                min=int(data['SalePrice'].min()),
                max=int(data['SalePrice'].max()),
                step=1000,
                value=[int(data['SalePrice'].min()), int(data['SalePrice'].max())],
                tooltip={"placement": "bottom", "always_visible": True}
            )
        ], style={'flex': '2', 'padding': '0 10px'}),
    ], style={'display': 'flex', 'alignItems': 'center', 'marginBottom': '30px'})

# ---------------------------------------------------------------
# 8️⃣ Tab Layout
# ---------------------------------------------------------------
app.layout = html.Div([
    html.H1("🏠 Ames Housing Dashboard", style={'textAlign': 'center', 'marginBottom': '20px'}),

    dcc.Tabs(id='tabs', value='tab-eda', children=[
        dcc.Tab(label='📊 Exploratory Data Analysis (EDA)', value='tab-eda'),
        dcc.Tab(label='🤖 Model & Predictions', value='tab-model'),
    ]),

    html.Div(id='tabs-content')
])

# ---------------------------------------------------------------
# 9️⃣ Tab Contents
# ---------------------------------------------------------------
@app.callback(Output('tabs-content', 'children'), Input('tabs', 'value'))
def render_tab_content(tab):
    if tab == 'tab-eda':
        return html.Div([
            html.H3("📊 Exploratory Data Analysis (EDA)", style={'textAlign': 'center'}),
            filter_controls("eda", clean_data),
            html.Div([
                dcc.Graph(id='eda-scatter', style={'flex': '2'}),
                dcc.Graph(id='eda-box', style={'flex': '1'})
            ], style={'display': 'flex', 'flexWrap': 'wrap', 'gap': '20px'}),
            html.Div([dcc.Graph(id='eda-hist', style={'width': '100%'})])
        ])
    elif tab == 'tab-model':
        return html.Div([
            html.H3("🤖 Model & Prediction Visualization", style={'textAlign': 'center'}),
            html.P(f"Linear Regression - R²: {r2:.4f}", style={'textAlign': 'center', 'fontSize': '18px'}),
            filter_controls("model", X_test_copy),
            html.Div([
                dcc.Graph(id='model-scatter', style={'flex': '2'}),
                dcc.Graph(id='model-box', style={'flex': '1'})
            ], style={'display': 'flex', 'flexWrap': 'wrap', 'gap': '20px'}),
            html.Div([dcc.Graph(id='model-hist', style={'width': '100%'})])
        ])

# ---------------------------------------------------------------
# 🔟 CALLBACKS – EDA Tab
# ---------------------------------------------------------------
@app.callback(
    [Output('eda-scatter', 'figure'),
     Output('eda-box', 'figure'),
     Output('eda-hist', 'figure')],
    [Input('eda-neighborhood-dropdown', 'value'),
     Input('eda-kitchenqual-dropdown', 'value'),
     Input('eda-price-slider', 'value')]
)
def update_eda_graphs(neighborhoods, kitchenquals, price_range):
    filtered_df = clean_data[
        (clean_data['Neighborhood'].isin(neighborhoods)) &
        (clean_data['Kitchen_Qual'].isin(kitchenquals)) &
        (clean_data['SalePrice'] >= price_range[0]) &
        (clean_data['SalePrice'] <= price_range[1])
    ]

    scatter_fig = px.scatter(filtered_df, x='Lot_Area', y='SalePrice', color='Neighborhood',
                             title="Lot_Area vs SalePrice (EDA)")
    box_fig = px.box(filtered_df, x='Neighborhood', y='SalePrice',
                     title="Price Distribution by Neighborhood (EDA)")
    hist_fig = px.histogram(filtered_df, x='SalePrice', nbins=50, title="SalePrice Distribution (EDA)")
    return scatter_fig, box_fig, hist_fig

# ---------------------------------------------------------------
# 1️⃣1️⃣ CALLBACKS – Model Tab
# ---------------------------------------------------------------
@app.callback(
    [Output('model-scatter', 'figure'),
     Output('model-box', 'figure'),
     Output('model-hist', 'figure')],
    [Input('model-neighborhood-dropdown', 'value'),
     Input('model-kitchenqual-dropdown', 'value'),
     Input('model-price-slider', 'value')]
)
def update_model_graphs(neighborhoods, kitchenquals, price_range):
    filtered_df = X_test_copy[
        (X_test_copy['Neighborhood'].isin(neighborhoods)) &
        (X_test_copy['Kitchen_Qual'].isin(kitchenquals)) &
        (X_test_copy['SalePrice'] >= price_range[0]) &
        (X_test_copy['SalePrice'] <= price_range[1])
    ].copy()

    scatter_fig = px.scatter(filtered_df, x='Lot_Area', y='SalePrice', color='Neighborhood',
                             title="Lot_Area vs SalePrice (Actual)")
    scatter_fig.add_traces(
        px.scatter(filtered_df, x='Lot_Area', y='Predicted_Price',
                   color_discrete_sequence=['red']).data
    )

    box_fig = px.box(filtered_df, x='Neighborhood', y='SalePrice',
                     title="Price Distribution by Neighborhood (Actual vs Predicted)")
    hist_fig = px.histogram(filtered_df, x='SalePrice', nbins=50, title="SalePrice Distribution (Test Set)")
    return scatter_fig, box_fig, hist_fig

# ---------------------------------------------------------------
# 1️⃣2️⃣ Run App
# ---------------------------------------------------------------
if __name__ == '__main__':
    app.run(debug=False, use_reloader=False)

